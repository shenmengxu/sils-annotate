
/*
** Annotator v1.2.9
** https://github.com/okfn/annotator/
**
** Copyright 2013, the Annotator project contributors.
** Dual licensed under the MIT and GPLv3 licenses.
** https://github.com/okfn/annotator/blob/master/LICENSE
**
** Built at: 2013-12-02 17:58:01Z
 */


//# sourceMappingURL=_preamble.map
